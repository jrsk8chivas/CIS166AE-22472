<?php // Script 13.9 - edit_order.php
/* This script edits a order. */

// Define a page title and include the header:
define('TITLE', 'Edit an Order');
include('templates/header.html');

print '<h1 class="container">Update My Order</h1>';

// Need the database connection:
include('../mysqli_connect.php');

if (isset($_GET['id']) && is_numeric($_GET['id']) && ($_GET['id'] > 0) ) { // Display the entry in a form:

	// Define the query.
	$query = "SELECT * FROM orders WHERE id={$_GET['id']}";
	if ($result = mysqli_query($dbc, $query)) { // Run the query.

		$row = mysqli_fetch_array($result); // Retrieve the information.

		// Make the form:
		print '<div class="container">
		
		<form action="edit_order.php" method="post">
			<p><label>First Name </label><br>
			<input type="text" name="firstname" value="' . htmlentities($row['firstname']) . '"required></p>
			
			<p><label>Last Name </label><br>
			<input type="text" name="lastname" value="' . htmlentities($row['lastname']) . '"required></p>
			
			<p><label>Street Address </label><br>
			<input type="text" name="address" value="' . htmlentities($row['address']) . '"required></p>
			
			<p><label>City </label><br>
			<input type="text" name="city" value="' . htmlentities($row['city']) . '"required></p>		
			
			<p><label>State</label><br>
			<select name="state" required>
				<option value="" disabled selected hidden>** Select a State **</option>
				<option value="AL">Alabama</option>
				<option value="AK">Alaska</option>
				<option value="AZ">Arizona</option>
				<option value="AR">Arkansas</option>
				<option value="CA">California</option>
				<option value="CO">Colorado</option>
				<option value="CT">Connecticut</option>
				<option value="DE">Delaware</option>
				<option value="DC">District Of Columbia</option>
				<option value="FL">Florida</option>
				<option value="GA">Georgia</option>
				<option value="HI">Hawaii</option>
				<option value="ID">Idaho</option>
				<option value="IL">Illinois</option>
				<option value="IN">Indiana</option>
				<option value="IA">Iowa</option>
				<option value="KS">Kansas</option>
				<option value="KY">Kentucky</option>
				<option value="LA">Louisiana</option>
				<option value="ME">Maine</option>
				<option value="MD">Maryland</option>
				<option value="MA">Massachusetts</option>
				<option value="MI">Michigan</option>
				<option value="MN">Minnesota</option>
				<option value="MS">Mississippi</option>
				<option value="MO">Missouri</option>
				<option value="MT">Montana</option>
				<option value="NE">Nebraska</option>
				<option value="NV">Nevada</option>
				<option value="NH">New Hampshire</option>
				<option value="NJ">New Jersey</option>
				<option value="NM">New Mexico</option>
				<option value="NY">New York</option>
				<option value="NC">North Carolina</option>
				<option value="ND">North Dakota</option>
				<option value="OH">Ohio</option>
				<option value="OK">Oklahoma</option>
				<option value="OR">Oregon</option>
				<option value="PA">Pennsylvania</option>
				<option value="RI">Rhode Island</option>
				<option value="SC">South Carolina</option>
				<option value="SD">South Dakota</option>
				<option value="TN">Tennessee</option>
				<option value="TX">Texas</option>
				<option value="UT">Utah</option>
				<option value="VT">Vermont</option>
				<option value="VA">Virginia</option>
				<option value="WA">Washington</option>
				<option value="WV">West Virginia</option>
				<option value="WI">Wisconsin</option>
				<option value="WY">Wyoming</option>
			</select></p>				
			
			<p><label>Zip Code </label><br>
			<input type="text" name="zip" size="50" pattern="[0-9]{5}"  value="' . htmlentities($row['zip']) . '"required></p>	
			
			<p><label>Email Address </label><br>
		    <input type="email" name="email" size="50" value="' . htmlentities($row['email']) . '"required></p>
			
			<p><label>Confirm Email Address </label><br>
		    <input type="email" name="confirm" size="50" value="' . htmlentities($row['email']) . '"required></p>
			
			<p><label>Phone Number</label><br>
			<input type="tel" name="phone" size="50" placeholder="5555555555" value="' . htmlentities($row['phone']) . '"required></p>		
			
			<p><label>Quantity</label><br>
			<input type="number" name="quantity" size="70" min="1" value="1"></p>
			</div>'	;	
		
		// Complete the form:
		print '<div class="container">
			<input type="hidden" name="id" value="' . $_GET['id'] . '">
			<p><input class="button" type="submit" name="submit" value="Update This order!"></p></div>
			</form>';

	} else { // Couldn't get the information.
		print '<p class="error">Could not retrieve the order because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
	}
} elseif (isset($_POST['id']) && is_numeric($_POST['id']) && ($_POST['id'] > 0)) { // Handle the form.

	// Validate and secure the form data:
	$okay = true;
	if ( !empty($_POST['firstname']) && !empty($_POST['lastname']) ) {

		// Prepare the values for storing:
		$firstname = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['firstname'])));
		$lastname = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['lastname'])));
		$address = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['address'])));
		$city = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['city'])));
		$state = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['state'])));
		$zip = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['zip'])));
		$email = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['email'])));
		$phone = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['phone'])));
		$quantity = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['quantity'])));	
		$okay = true;
		$phone = phone_number_format($phone);
	
		//validate phone number:
		if(empty($phone)){
			print('<p class="error">Your phone number was not valid.</p>');
			print('<p class="errorResubmit">Please enter a 10 digit phone number and submit again!</p>');
			$okay=false;
		}
	
		//Validate email for format, and that emails match. Normally I would match the entire email, but am demonstrating comparing two substrings.
		//Also control structure:
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
			
			//compare substrings
			if(strtok($_POST['email'],'@') != strtok($_POST['confirm'],'@')) {
				//error msg when format and confirmation are incorrect:
				print('<p class="error">**Your email format is invalid.<br>**Your confirmed email does not match.</p>');
				print('<p class="errorResubmit">Please correct your email address and submit again!</p>');
				$okay=false;
			//error msg when only the email format is incorrect:
			}	else {
				print('<p class="errorResubmit"> Please correct your email format and submit again!</p>');	
				$okay=false;
			}
		//error msg when just the emails don't match:
		} else {
			if (strtok($_POST['email'],'@') != strtok($_POST['confirm'],'@')) {
				print('<p class="errorResubmit">Please make your email and confirmation match and submit again!</p>');		
				$okay=false;		
			}
		}

	} else {
		print '<p class="error">Please submit all fields.</p>';
		$okay = FALSE;
	}

	if ($okay) {
		// Define the query.
		$query = "UPDATE orders 
		SET firstname='$firstname', lastname='$lastname', address='$address', city='$city', state='$state', zip='$zip', email='$email', phone='$phone', quantity='$quantity' 
		WHERE id={$_POST['id']}";
		
				//set price, tax variables:
		$price = 6;
		$taxrate = 1.075;
		
		//calculate cost
		$cost = $quantity * $price;
		$cost_with_tax = $cost * $taxrate;	
		
		if ($result = mysqli_query($dbc, $query)) {
						// Print a message:
			print("<div class='container'>
			<p class='errorResubmit'>$firstname $lastname, your CD(s) order has been updated.</p>");
			
				print "<table id='orders'> 
				  <tr> 
					<th>Order</th> 
					  <th>Name</th> 
					  <th>Address</th> 
					  <th>Email</th> 
					  <th>Phone</th> 
					  <th style='text-align:center'>Quantity</th> 
					  <th>Cost</th>
					  <th style='text-align:center'>Change Order</th>
				  </tr>";
			print 
		'<tr> 
			<td>'.$_POST['id'].'</td>
			<td>'.$firstname.' '.$lastname.'</td> 
			<td>'.$address.' '.$city.' '.$state.' '.$zip.'</td> 
			<td>'.$email.'</td> 
			<td>'.$phone.'</td>
			<td style="text-align:center">'.$quantity.'</td> 
			<td>'.$cost_with_tax.'</td> 
			<td align="center">';
				print "<a href=\"edit_order.php?id={$_POST['id']}\">Edit</a> |
		<a href=\"delete_order.php?id={$_POST['id']}\">Delete</a>";'</td>
    	</tr>';	
		
				print('</table><br>');
			
							
		print("<form class='container' action='orders.php'>
        <button class='button' type='submit'>View All Orders</button>
      	</form>");
		print("<br><form class='container' action='index.php'>
        <button class='button' type='submit'>Make Another Order</button>
      	</form>");
			
		} else {
			print '<p class="error">Could not update the order because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
		}

	} // No problem!
} else { // No ID set.
	print '<p class="error">This page has been accessed in error.</p>';
}
mysqli_close($dbc); // Close the connection.

include('templates/footer.html'); // Include the footer.
?>