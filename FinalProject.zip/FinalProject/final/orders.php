<?php //  orders.php
/* displays:
- order history
-links to add, delete, or change orders*/

// Include the header:
define('TITLE', 'View all Orders');
include('templates/header.html');

print '<h1 class="container">All Orders</h1>';
	
// Need the database connection:
include('../mysqli_connect.php');

$query = "SELECT *, quantity * 6 * 1.075 AS cost FROM orders ORDER BY id DESC";

	print "<table id='orders'> 
      <tr> 
	  	<th>Order</th> 
          <th>Name</th> 
          <th>Address</th> 
          <th>Email</th> 
          <th>Phone</th>
          <th style='text-align:center'>Quantity</th> 
          <th>Cost</th>
		  <th style='text-align:center'>Change Order</th>
      </tr>";
 
// Run the query:
if ($result = mysqli_query($dbc, $query)) {
    while ($row = $result->fetch_assoc()) {
        $id = $row["id"];
		$firstname = $row["firstname"];
		$lastname = $row["lastname"];
        $address = $row["address"];
		$city = $row["city"];
		$state = $row["state"];
        $zip = $row["zip"];
		$email = $row["email"];
        $phone = $row["phone"];
 		$quantity = $row["quantity"];
        $cost = '$' . number_format($row["cost"], 2); 
		
      print 
		'<tr> 
			<td>'.$id.'</td>
			<td>'.$firstname.' '.$lastname.'</td> 
			<td>'.$address.' '.$city.' '.$state.' '.$zip.'</td> 
			<td>'.$email.'</td> 
			<td>'.$phone.'</td> 
			<td style="text-align:center">'.$quantity.'</td> 
			<td>'.$cost.'</td> 
			<td align="center">';
				print "<a href=\"edit_order.php?id={$row['id']}\">Edit</a> |
		<a href=\"delete_order.php?id={$row['id']}\">Delete</a>";'</td>
    	</tr>';		
	}
	print('</table>');
    $result->free(); 
	
} else { // Query didn't run.
	print '<p class="error">Could not retrieve the data because:<br>' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
} // End of query IF.

			print("<br><form class='container' action='index.php'>
         		<button class='button' type='submit'>Make a New Order</button>
      			</form>");

mysqli_close($dbc); // Close the connection.

echo('</div>');
include('templates/footer.html'); // Include the footer.
?>